package it.caos;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.core.Holder;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.enchantment.Enchantment;

public class CaosInventario implements ModInitializer {
	/** 20 tick = 1 secondo, quindi 80 tick = 4 secondi. */
	private static final int INTERVALLO_INCANTESIMI = 80;
	/** Slot dello zaino e della hotbar: le copie vengono messe solo qui. */
	private static final int SLOT_ZAINO = 36;

	/** Vita (più assorbimento) subito prima del colpo. */
	private final Map<UUID, Float> vitaPrima = new HashMap<>();
	/** Danno non ancora sufficiente a formare un cuore intero. */
	private final Map<UUID, Float> dannoAccumulato = new HashMap<>();

	@Override
	public void onInitialize() {
		ServerLivingEntityEvents.ALLOW_DAMAGE.register((entity, source, amount) -> {
			if (entity instanceof ServerPlayer player) {
				vitaPrima.put(player.getUUID(), vitaTotale(player));
			}
			return true;
		});

		// Si misura la vita persa davvero, quindi armatura e protezioni contano.
		ServerLivingEntityEvents.AFTER_DAMAGE.register((entity, source, base, subito, bloccato) -> {
			if (!(entity instanceof ServerPlayer player)) return;
			Float prima = vitaPrima.remove(player.getUUID());
			if (prima == null) return;

			float perso = prima - vitaTotale(player);
			if (perso <= 0) return;

			float totale = dannoAccumulato.getOrDefault(player.getUUID(), 0f) + perso;
			int cuori = (int) ((totale + 0.001f) / 2f);
			dannoAccumulato.put(player.getUUID(), Math.max(0f, totale - cuori * 2f));

			if (cuori > 0) {
				// 1 cuore = x2, 2 cuori = x3, 3 cuori = x4...
				int moltiplicatore = cuori + 1;
				moltiplica(player.getInventory(), moltiplicatore);
				player.sendSystemMessage(Component.literal("Item moltiplicati x" + moltiplicatore + "!"));
			}
		});

		ServerLivingEntityEvents.AFTER_DEATH.register((entity, source) -> {
			vitaPrima.remove(entity.getUUID());
			dannoAccumulato.remove(entity.getUUID());
		});

		ServerTickEvents.END_SERVER_TICK.register(server -> {
			if (server.getTickCount() % INTERVALLO_INCANTESIMI != 0) return;
			for (ServerPlayer player : server.getPlayerList().getPlayers()) {
				if (player.isAlive() && !player.isSpectator()) {
					incanta(player);
				}
			}
		});
	}

	private static float vitaTotale(ServerPlayer player) {
		return player.getHealth() + player.getAbsorptionAmount();
	}

	/** Moltiplica ogni pila. Quello che non entra nell'inventario va perso (evita il lag). */
	private static void moltiplica(Inventory inventario, int moltiplicatore) {
		// Prima si fotografa l'inventario, così le copie nuove non vengono rimoltiplicate.
		List<ItemStack> modelli = new ArrayList<>();
		List<Integer> quantita = new ArrayList<>();
		for (int i = 0; i < inventario.getContainerSize(); i++) {
			ItemStack pila = inventario.getItem(i);
			if (!pila.isEmpty()) {
				modelli.add(pila.copy());
				quantita.add(pila.getCount());
			}
		}

		for (int i = 0; i < modelli.size(); i++) {
			long extra = (long) quantita.get(i) * (moltiplicatore - 1);
			aggiungi(inventario, modelli.get(i), extra);
		}
	}

	private static void aggiungi(Inventory inventario, ItemStack modello, long extra) {
		int massimo = modello.getMaxStackSize();

		// 1) riempie le pile identiche già presenti
		for (int i = 0; i < SLOT_ZAINO && extra > 0; i++) {
			ItemStack pila = inventario.getItem(i);
			if (!pila.isEmpty() && ItemStack.isSameItemSameComponents(pila, modello)) {
				int spazio = massimo - pila.getCount();
				if (spazio > 0) {
					int n = (int) Math.min(spazio, extra);
					pila.grow(n);
					extra -= n;
				}
			}
		}

		// 2) usa gli slot vuoti
		for (int i = 0; i < SLOT_ZAINO && extra > 0; i++) {
			if (inventario.getItem(i).isEmpty()) {
				int n = (int) Math.min(massimo, extra);
				inventario.setItem(i, modello.copyWithCount(n));
				extra -= n;
			}
		}
	}

	/** Dà a ogni item un incantesimo a caso, senza controllare la compatibilità. */
	private static void incanta(ServerPlayer player) {
		List<Holder.Reference<Enchantment>> incantesimi = player.level().registryAccess()
				.lookupOrThrow(Registries.ENCHANTMENT)
				.listElements()
				.toList();
		if (incantesimi.isEmpty()) return;

		Inventory inventario = player.getInventory();
		for (int i = 0; i < inventario.getContainerSize(); i++) {
			ItemStack pila = inventario.getItem(i);
			if (pila.isEmpty()) continue;

			Holder.Reference<Enchantment> scelto =
					incantesimi.get(player.getRandom().nextInt(incantesimi.size()));
			int livello = 1 + player.getRandom().nextInt(scelto.value().getMaxLevel());
			pila.enchant(scelto, livello);
		}
	}
}
